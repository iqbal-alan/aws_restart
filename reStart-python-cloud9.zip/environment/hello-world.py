print("Hello, Say")
print(" lagi ngapain nih ?")

mystandar=5
print(mystandar)