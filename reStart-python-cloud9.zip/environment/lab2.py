print("Python has three numeric types: int, float, and complex")

myValue="sayang"
print(myValue)
print(type(myValue))


myValue1=3.13
print(myValue1)
print(type(myValue1))


myValue2=5J
print(myValue2)
print(type(myValue2))


myValue3=True
print(myValue3)
print(type(myValue3))


myValue4=False
print(myValue4)
print(type(myValue4))
