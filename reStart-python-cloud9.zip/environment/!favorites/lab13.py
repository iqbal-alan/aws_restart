

def penjumlahan():
    a=5
    b=7
    hasil = a+b
    return hasil

print("ini adalah contoh fungsi penjumlahan")  
print(penjumlahan())


def pengurangan(x,y):
    c= x-y
    return c
    
print("ini adalah contoh fungsi pengurangan") 
print(pengurangan(5,3))
